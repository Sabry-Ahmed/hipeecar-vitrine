import React from 'react';
import './index.css';

export default function Main() {
  return (
    <div className='main-container'>
      <div className='section'>
        <div className='pic' />
        <div className='wrapper'>
          <div className= 'textcliclk'>
          <span className='text'>Qui sommes-nous </span>
          </div>
          <div className= 'textcliclk'>
          <span className='text-2'>Devenir Agent</span>
          </div>
          <div className= 'textcliclk'>
            <span className='text-3'>Vendre mon véhicule</span>
          </div>
          <div className= 'textcliclk'>
          <span className='text-4'>Comment ça marche ?</span>
          </div>
          <div className='wrapper-2'>
            <span className='text-5'>CONNEXION</span>
          </div>
        </div>
      </div>
      <div className='section-2'>
        <div className='box'>
          <div className='section-3'>
            <span className='text-6'>Devenez vendeur automobile <br />avec  0€ d’apport !</span>
            <span className='text-7'>
              
            </span>
          </div>
          <span className='text-8'>
            Hipeecar vous donne la possibilité de gagner un complément de revenu
            et de devenir vendeur de voitures gratuitement et en quelques clics
            seulement. En devenant agent Hipeecar, vous aurez à votre
            disposition un garage en ligne qui vous permettra de partager
            simplement vos véhicules à vos proches et ainsi obtenir de belles
            commissions.
            <br />
          </span>
          <div className='section-4'>
            <div className='wrapper-3'>
              <span className='text-9'>Je m’inscris ici </span>
              <div className='img' />
            </div>
          </div>
          <div className='pic-2' />
          <span className='text-a'>
            Des milliers de nouvelles voitures chaque jour
            <br />
          </span>
          <span className='text-b'>
            Chaque jour, de nouvelles voitures sont ajoutées dans vos garages en
            ligne. Les véhicules sont minutieusement contrôlés par nos experts
            afin de vous assurer les bonnes affaires à recommander à vos
            contacts.
            <br />
          </span>
          <div className='pic-3' />
          <span className='text-c'>
            Gagner de l’argent à votre rythme
            <br />
            <br />
          </span>
          <span className='text-d'>
            Que vous soyez un étudiant à la recherche d’argents de poche, un
            employé à la quête d’un complément de revenu ou un entrepreneur qui
            souhaite faire de la vente automobile son métier… Hipeecar met à
            votre disposition tout un écosystème pour vous permettre de gagner
            de l’argent à votre rythme.
            <br />
          </span>
          <span className='text-e'>
            Gratuit et en quelques clics seulement
            <br />
          </span>
          <div className='pic-4' />
          <span className='text-f'>1</span>
          <span className='text-10'>Créez votre compte</span>
          <div className='img-2' />
          <span className='text-11'>
            Recommandez les voitures de votre choix
            <br />
          </span>
          <span className='text-12'>2</span>
          <div className='pic-5' />
          <span className='text-13'>3</span>
          <span className='text-14'>
            Recevez vos commissions
            <br />
            <br />
          </span>
        </div>
        <div className='img-3'>
          <div className='pic-6'>
            <div className='pic-7'>
              <div className='pic-8'>
                <div className='box-2'>
                  <span className='text-15'>
                    Hey ! Regarde la voiture que j’ai trouvé sur
                  </span>
                  <span className='text-16'>www.hipeecar.fr</span>
                </div>
              </div>
              <div className='wrapper-4'>
                <div className='section-5'>
                  <span className='text-17'>
                    Bien sur. Tu peux toutes les retrouver
                    <br />
                    sur mon e-garage : 
                  </span>
                  <span className='text-18'>www.hipeecar.fr/eg/1897</span>
                </div>
              </div>
            </div>
            <div className='group' />
            <span className='text-19'>
              Magnifique ! T'en as d'autres à me montrer ?<br />
            </span>
            <div className='wrapper-5' />
            <span className='text-1a'>
              Je cherche ce modèle là.
              <br />
            </span>
            <div className='pic-9' />
          </div>
        </div>
        <div className='section-6' />
      </div>
      <div className='box-3'>
        <span className='text-1b'>
          Créez un compte pour commencer l’aventure
          <br />
          <br />
        </span>
        <span className='text-1c'>Je suis un :</span>
        <div className='group-2'>
          <span className='text-1d'>Particulier</span>
          <span className='text-1e'>Professionnel</span>
          <div className='img-4' />
          <div className='img-5' />
        </div>
        <div className='wrapper-6'>
          <span className='text-1f'>Nom</span>
          <span className='text-20'>Prénom</span>
        </div>
        <div className='section-7'>
          <div className='wrapper-7'>
            <span className='text-21'>Nom</span>
          </div>
          <div className='section-8'>
            <span className='text-22'>Prénom</span>
          </div>
        </div>
        <div className='section-9'>
          <span className='text-23'>E-mail</span>
          <span className='text-24'>Téléphone</span>
        </div>
        <div className='group-3'>
          <div className='section-a'>
            <span className='text-25'>monemail@gmail.com</span>
          </div>
          <div className='box-4'>
            <span className='text-26'>0699999999</span>
          </div>
        </div>
        <div className='wrapper-8'>
          <span className='text-27'>Mot de passe</span>
          <span className='text-28'>Confirmation</span>
        </div>
        <div className='group-4'>
          <div className='wrapper-9'>
            <span className='text-29'>***************</span>
          </div>
          <div className='wrapper-a'>
            <span className='text-2a'>***************</span>
          </div>
        </div>
        <div className='wrapper-b'>
          <span className='text-2b'>Devenir agent</span>
        </div>
      </div>
      <div className='box-5'>
        <div className='section-b'>
          <span className='text-2c'>A propos de Hipeecar</span>
          <span className='text-2d'>Informations</span>
          <span className='text-2e'>Aide</span>
          <div className='pic-a' />
          <span className='text-2f'>Qui sommes-nous ?</span>
          <span className='text-30'>C.G.U.</span>
          <span className='text-31'>FAQ</span>
          <span className='text-32'>Comment ça marche ?</span>
          <span className='text-33'>Mentions légales</span>
          <span className='text-34'>Contact</span>
          <span className='text-35'>Blog Hipeecar</span>
          <span className='text-36'>C.G.U. MangoPay</span>
        </div>
      </div>
    </div>
  );
}
