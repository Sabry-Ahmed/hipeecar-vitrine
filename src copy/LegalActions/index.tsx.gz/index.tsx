import React from 'react';
import './index.css';

export default function Main() {
  return (
    <div className='main-container'>
      <div className='section'>
        <div className='pic' />
        <div className='group'>
          <div className= 'textcliclk'>
          <span className='text'>Qui sommes-nous </span>
          </div>
          <div className= 'textcliclk'>
          <span className='text-2'>Devenir Agent</span>
          </div>
          <div className= 'textcliclk'>
            <span className='text-3'>Vendre mon véhicule</span>
          </div>
          <div className= 'textcliclk'>
          <span className='text-4'>Comment ça marche ?</span>

          </div>



          <div className='box'>
            <span className='text-5'>CONNEXION</span>
          </div>
        </div>
      </div>
      <span className='text-6'>
        MENTIONS LEGALES
        <br />
      </span>
      <div className='group-2'>
        <span className='text-7'>
          Informations générales
          <br />
          <br />
          <br />
          <br />
        </span>
        <span className='tst'>
          Propriété intellectuelle
          <br />
          <br />
        </span>
      </div>
      <div className='group-3'>
        <span className='text-9'>
          Le site hipeecar.fr est la propriété de la société HIPEECAR.
          <br />
          La S.A.S.U. HIPEECAR, est la société éditrice du site hipeecar.fr, au
          capital de 3.000 €, immatriculée au registre du commerce et des
          sociétés de NANTERRE sous le numéro 832 048 425 R.C.S, dont le siège
          social se situe au :<br />
          <br />
          11, avenue Marc Sangnier92390 Villeneuve la Garenne.
          <br />
          <br />
          En utilisant le site, l'utilisateur reconnaît avoir pris connaissance
          de ses conditions et les avoir acceptées. Celles-ci pourront être
          modifiées à tout moment et sans préavis par la société HIPEECAR.
          <br />
          <br />
          Par ailleurs, l'utilisateur reconnaît avoir été informé que le présent
          site est accessible 24 heures sur 24 et 7 jours sur 7, à l'exception
          des cas de force majeure, difficultés informatiques, difficultés liées
          à la structure des réseaux de communication ou difficultés techniques.
          Pour des raisons de maintenance, la société HIPEECAR pourra
          interrompre le site et s'efforcera d'en avertir préalablement les
          utilisateurs.
          <br />
          <br />
          L'hébergement du site est assuré par :<br />
          o2switch222-224 Boulevard Gustave Flaubert63000 Clermont-FerrandSiret
          510 909 80700024
        </span>
        <span className='text-a'>
          Tout le contenu du site hipeecar.fr, ainsi que les graphismes, images,
          textes, logos et leur mise en forme sont la propriété exclusive de la
          société HIPEECAR à l'exception des marques, logos ou contenus
          appartenant à d'autres sociétés partenaires.
          <br />
          Toute représentation totale ou partielle de ce site par quelque
          procédé que ce soit, sans l'autorisation expresse de la société
          HIPEECAR est interdite et constituerait une contrefaçon sanctionnée
          par les articles L.335-2 et suivants du code de la propriété
          intellectuelle.
          <br />
          Toute reproduction totale ou partielle des marques ou logos de la
          société HIPEECAR ou de ses partenaires, effectuée à partir des
          éléments du site sans l'autorisation expresse de la société HIPEECAR
          ou du propriétaire du logo ou de la marque est prohibée selon le code
          de la propriété intellectuelle.
        </span>
        <span className='text-b'>
          Attribution de juridiction
          <br />
          <br />
          <br />
        </span>
        <span className='text-c'>
          En cas de litige entre la société HIPEECAR et tout tiers du fait du
          présent site, la juridiction compétente sera celle dont ressort le
          siège social de la société HIPEECAR.
        </span>
      </div>
      <div className='wrapper'>
        <div className='wrapper-2'>
          <span className='text-d'>A propos de Hipeecar</span>
          <span className='text-e'>Informations</span>
          <span className='text-f'>Aide</span>
          <div className='pic-2' />
          <span className='text-10'>Qui sommes-nous ?</span>
          <span className='text-11'>C.G.U.</span>
          <span className='text-12'>FAQ</span>
          <span className='text-13'>Comment ça marche ?</span>
          <span className='text-14'>Mentions légales</span>
          <span className='text-15'>Contact</span>
          <span className='text-16'>Blog Hipeecar</span>
          <span className='text-17'>C.G.U. MangoPay</span>
        </div>
      </div>
    </div>
  );
}
