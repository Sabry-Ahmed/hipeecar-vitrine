import React from 'react';
import './index.css';

export default function Main() {
  return (
    <div className='main-container'>
      <div className='section'>
        <div className='img' />
        <div className='wrapper'>
          <div className= 'textcliclk'>
          <span className='text'>Qui sommes-nous </span>
          </div>
          <div className= 'textcliclk'>
          <span className='text-2'>Devenir Agent</span>
          </div>
          <div className= 'textcliclk'>
            <span className='text-3'>Vendre mon véhicule</span>
          </div>
          <div className= 'textcliclk'>
          <span className='text-4'>Comment ça marche ?</span>

          </div>

          <div className='section-2'>
            <span className='text-5'>CONNEXION</span>
          </div>
        </div>
      </div>
      <div className='box'>
        <div className='group'>
          <span className='text-6'>
            Qui sommes-nous ?<br />
          </span>
          <span className='text-7'>
            Vous ne serez plus seul à vouloir vendre votre voiture
            <br />
            <br />
          </span>
          <span className='text-8'>
            En devenant agent, vous aurez à votre disposition un garage en ligne
            rien que pour vous. Cet espace vous permettra de présenter les
            voitures de votre choix. Vous serez également notifié des meilleures
            occasions. Le garage en ligne vous permettra également de suivre vos
            ventes et de répondre aux messages des potentiels acheteurs.
            <br />
            <br />
          </span>
          <span className='text-9'>
            Une communauté d’agents pour vendre votre voiture
            <br />
          </span>
          <span className='text-a'>
            Notre communauté rassemble des agents motivés, répartis dans toute
            la France et venant de tous horizons. Ils peuvent être étudiants à
            la recherche d’argents de poche, employés à la quête d’un complément
            de revenu ou entrepreneurs qui souhaitent faire de la vente
            automobile leur métier… Leur seul objectif c’est de vendre votre
            voiture !<br />
            <br />
          </span>
          <span className='text-b'>
            Disponible dans toutes les régions de France
            <br />
          </span>
          <span className='text-c'>
            Notre solution est présente dans toutes les régions de France et
            offre aux personnes souhaitant vendre leur véhicule une nouvelle
            alternative, plus efficace pour trouver des acheteurs à leurs
            automobiles grâce à la recommandation faite par nos agents à leurs
            proches.
            <br />
            <br />
            <br />
          </span>
          <div className='wrapper-2'>
            <div className='box-2'>
              <div className='wrapper-3'>
                <span className='text-d'>Je veux devenir agent.</span>
              </div>
            </div>
            <div className='section-3'>
              <div className='wrapper-4'>
                <span className='text-e'>Je veux vendre ma voiture</span>
              </div>
            </div>
          </div>
        </div>
        <div className='section-4'>
          <div className='group-2' />
          <div className='img-2' />
        </div>
        <div className='box-3'>
          <div className='group-3'>
            <span className='text-f'>A propos de Hipeecar</span>
            <span className='text-10'>Informations</span>
            <span className='text-11'>Aide</span>
            <div className='pic' />
            <span className='text-12'>Qui sommes-nous ?</span>
            <span className='text-13'>C.G.U.</span>
            <span className='text-14'>FAQ</span>
            <span className='text-15'>Comment ça marche ?</span>
            <span className='text-16'>Mentions légales</span>
            <span className='text-17'>Contact</span>
            <span className='text-18'>Blog Hipeecar</span>
            <span className='text-19'>C.G.U. MangoPay</span>
          </div>
        </div>
      </div>
    </div>
  );
}
