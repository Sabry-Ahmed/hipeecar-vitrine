import React from 'react';

import Page from './page'
import Vendeur from './Vendeur/Vendeur'
import Agents from './Agents'
import Fonctionnement from './Fonctinemment'
import Mainpage from './MainPage'
import LegalActions from './LegalActions'


export default function App() {
  return (
    <div>
      <LegalActions />

      
        {/* 
      <Page />
      <Vendeur />
      <Agents />
      <Fonctionnement />
      <LegalActions />
      <Mainpage />
      */}
    </div>
  );
}
