import React from 'react';
import './index.css';

export default function Main() {
  return (
    <div className='main-container'>
      <div className='wrapper'>
        <div className='img' />
        <div className='section'>
          <span className='text'>CONNEXION</span>
        </div>
        <div className= 'textcliclk'>
        <span className='text-2'>Comment ça marche ?</span>
          </div>
          <div className= 'textcliclk'>
        <span className='text-5'>Devenir Agent</span>
          </div>
          <div className= 'textcliclk'>
            <span className='text-3'>Vendre mon véhicule</span>

          </div>
          <div className= 'textcliclk'>
        <span className='text-4'>Qui sommes-nous </span>
          </div>
      </div>
      <div className='box'>
        <div className='box-2'>
          <div className='box-3'>
            <span className='text-6'>
              Une nouvelle manière de vendre votre voiture
              <br />
            </span>
            <span className='text-7'>
              <br />
            </span>
          </div>
          <span className='text-8'>
            Procédure longue, risques d’arnaques, démarche administrative
            fatigante… vendre sa voiture n’est pas de tout repos pour certains.
            Hipeecar vous aide à trouver un acheteur à votre véhicule en mettant
            à votre disposition des milliers d'agents dont le seul objectif est
            de vendre votre automobile en contrepartie d’une commission.
            <br />
            <br />
          </span>
          <div className='wrapper-2'>
            <div className='wrapper-3'>
              <span className='text-9'>Je m’inscris ici </span>
            </div>
          </div>
          <span className='text-a'>
            Gratuit et en quelques clics seulement
            <br />
          </span>
          <div className='img-3' />
          <span className='text-b'>
            Une communauté de plus de 5 000 agents
            <br />
          </span>
          <span className='text-c'>
            Des milliers d’agents de vente automobile sélectionnés
            minutieusement vont s’occuper de vendre votre voiture au meilleur
            prix. En fonction de votre zone géographique, les agents seront
            notifiés de l’ajout de votre annonce.
            <br />
          </span>
          <div className='img-4'>
            <div className='img-5' />
          </div>
          <span className='text-d'>
            Tout le monde est gagnant
            <br />
          </span>
          <span className='text-e'>
            En utilisant les services d’Hipeecar, vous offrez aux agents de
            faire de la vente d’automobiles un métier à plein temps. En
            contrepartie, les agents sont là pour vous éviter cette lourde
            tâche.
            <br />
          </span>
          <div className='pic' />
          <span className='text-f'>
            Pour les particuliers mais aussi pour les professionnels
            <br />
          </span>
          <span className='text-10'>
            Vous êtes un professionnel de la vente automobile ? Vous pouvez à
            travers Hipeecar, doubler vos ventes en peu de temps grâce à la
            vente par recommandation.
            <br />
          </span>
          <div className='pic-2' />
          <span className='text-11'>1</span>
          <span className='text-12'>Créez votre compte</span>
          <div className='img-6' />
          <span className='text-13'>
            Mettez votre véhicule en ligne
            <br />
          </span>
          <span className='text-14'>2</span>
          <div className='img-7' />
          <span className='text-15'>
            Fixez le montant de la voiture et de la commission
            <br />
          </span>
          <span className='text-16'>3</span>
          <div className='img-8' />
          <span className='text-17'>4</span>
          <span className='text-18'>
            Recevez votre argent
            <br />
          </span>
        </div>
        <div className='pic-3' />
        <div className='section-2' />
      </div>
      <div className='section-3'>
        <span className='text-19'>
          Créez un compte pour commencer l’aventure
          <br />
          <br />
        </span>
        <span className='text-1a'>Je suis un :</span>
        <div className='group'>
          <span className='text-1b'>Particulier</span>
          <span className='text-1c'>Professionnel</span>
          <div className='img-9' />
          <div className='pic-4' />
        </div>
        <div className='group-2'>
          <span className='text-1d'>Nom</span>
          <span className='text-1e'>Prénom</span>
        </div>
        <div className='wrapper-4'>
          <div className='wrapper-5'>
            <span className='text-1f'>Nom</span>
          </div>
          <div className='wrapper-6'>
            <span className='text-20'>Prénom</span>
          </div>
        </div>
        <div className='wrapper-7'>
          <span className='text-21'>E-mail</span>
          <span className='text-22'>Téléphone</span>
        </div>
        <div className='wrapper-8'>
          <div className='section-4'>
            <span className='text-23'>monemail@gmail.com</span>
          </div>
          <div className='box-4'>
            <span className='text-24'>0699999999</span>
          </div>
        </div>
        <div className='group-3'>
          <span className='text-25'>Mot de passe</span>
          <span className='text-26'>Confirmation</span>
        </div>
        <div className='wrapper-9'>
          <div className='section-5'>
            <span className='text-27'>***************</span>
          </div>
          <div className='section-6'>
            <span className='text-28'>***************</span>
          </div>
        </div>
        <div className='box-5'>
          <span className='text-29'>Vendre mon véhicule</span>
        </div>
      </div>
      <div className='section-7'>
        <div className='wrapper-a'>
          <span className='text-2a'>A propos de Hipeecar</span>
          <span className='text-2b'>Informations</span>
          <span className='text-2c'>Aide</span>
          <div className='img-a' />
          <span className='text-2d'>Qui sommes-nous ?</span>
          <span className='text-2e'>C.G.U.</span>
          <span className='text-2f'>FAQ</span>
          <span className='text-30'>Comment ça marche ?</span>
          <span className='text-31'>Mentions légales</span>
          <span className='text-32'>Contact</span>
          <span className='text-33'>Blog Hipeecar</span>
          <span className='text-34'>C.G.U. MangoPay</span>
        </div>
      </div>
    </div>
  );
}
